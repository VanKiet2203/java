
package com.User.home.GUI;

public interface CartUpdateListener {
    void onCartUpdated(String customerID);
}