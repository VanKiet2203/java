package com.ComponentandDatabase.Database_Connection;

public class TestConnection {
    public static void main(String[] args) {
        DatabaseConnection.testConnection();
    }
}