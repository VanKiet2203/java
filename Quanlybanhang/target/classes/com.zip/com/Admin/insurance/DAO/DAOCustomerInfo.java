package com.Admin.insurance.DAO;

public class DAOCustomerInfo {
}
