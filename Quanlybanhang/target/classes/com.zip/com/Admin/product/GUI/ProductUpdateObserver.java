
package com.Admin.product.GUI;

public interface ProductUpdateObserver {
     void onProductUpdated();
}
