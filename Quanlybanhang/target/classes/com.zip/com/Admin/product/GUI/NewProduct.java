package com.Admin.product.GUI;

import com.ComponentandDatabase.Components.MyCombobox;
import com.ComponentandDatabase.Components.MyPanel;
import com.ComponentandDatabase.Components.MyTextField;
import com.ComponentandDatabase.Components.MyButton;
import com.ComponentandDatabase.Components.CustomDialog;
import com.Admin.product.BUS.BusProduct;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;
import com.Admin.category.DTO.DTOCategory;
import com.Admin.product.DTO.DTOProduct;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.*;
import net.miginfocom.swing.MigLayout;
import java.awt.Dimension;

public class NewProduct extends javax.swing.JFrame {
    private int mouseX, mouseY;
    private JLabel lblTitle, lblProductID, lblProductName, lblColor, lblBattery,
            lblSpeed, lblPrice, lblQuantity, lblCate;
    private MyPanel panelTitle;
    private MyTextField txtProductID, txtProductName, txtColor, txtBattery, txtSpeed, txtPrice;
    private MyCombobox<String> cmbOperate;
    private MyButton bntupload, bntSave, bntReset;
    private JPanel panelUpload;
    private JSpinner spinnerQuantity;
    private JMenu menu;
    private String image;
    private BusProduct busProduct;

    public NewProduct() {
        initComponents();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        // cho phép kéo di chuyển cửa sổ
        bg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                mouseX = evt.getX();
                mouseY = evt.getY();
            }
        });
        bg.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                int x = evt.getXOnScreen();
                int y = evt.getYOnScreen();
                setLocation(x - mouseX, y - mouseY);
            }
        });

        init();
    }

    public void init() {
        // Layout chính: tiêu đề + nội dung
        bg.setLayout(new net.miginfocom.swing.MigLayout("fill, insets 10, wrap", "[grow]", "[][grow]"));
    
        // Panel tiêu đề
        panelTitle = new MyPanel(new net.miginfocom.swing.MigLayout("fill, insets 0"));
        panelTitle.setGradientColors(Color.decode("#1CB5E0"), Color.decode("#4682B4"), MyPanel.VERTICAL_GRADIENT);
    
        lblTitle = new JLabel("New Product", JLabel.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitle.setForeground(Color.WHITE);
        panelTitle.add(lblTitle, "growx, align center");
    
        bg.add(panelTitle, "growx, h 45!, wrap");
    
        // Panel nội dung 4 cột: [label][field] [label][field]
        JPanel contentPanel = new JPanel(new net.miginfocom.swing.MigLayout("insets 15, wrap 4, gapx 20, gapy 12","[right][250!][right][250!]"));
        contentPanel.setBackground(Color.WHITE);
    
        // ===== Hàng 1: Product ID / Product Name =====
        lblProductID = new JLabel("Product ID:");
        lblProductID.setFont(new Font("sansserif", Font.PLAIN, 16));
        txtProductID = makeTextField(); // GIỮ NGUYÊN kiểu MyTextField của bạn
        contentPanel.add(lblProductID);
        contentPanel.add(txtProductID, "growx, w 250!");
lblProductName = new JLabel("Product Name:");
        lblProductName.setFont(new Font("sansserif", Font.PLAIN, 16));
        txtProductName = makeTextField();
        contentPanel.add(lblProductName);
        contentPanel.add(txtProductName, "growx, w 250!");
// ===== Hàng 2: Color / Speed =====
        lblColor = new JLabel("Color:");
        lblColor.setFont(new Font("sansserif", Font.PLAIN, 16));
        txtColor = makeTextField();
        contentPanel.add(lblColor);
        contentPanel.add(txtColor, "growx, w 250!");
lblSpeed = new JLabel("Speed:");
        lblSpeed.setFont(new Font("sansserif", Font.PLAIN, 16));
        txtSpeed = makeTextField();
        contentPanel.add(lblSpeed);
        contentPanel.add(txtSpeed, "growx, w 250!");
// ===== Hàng 3: Battery Capacity / Price (Price Sell) =====
        lblBattery = new JLabel("Battery Capacity:");
        lblBattery.setFont(new Font("sansserif", Font.PLAIN, 16));
        txtBattery = makeTextField();
        contentPanel.add(lblBattery);
        contentPanel.add(txtBattery, "growx, w 250!");
lblPrice = new JLabel("Price:");
        lblPrice.setFont(new Font("sansserif", Font.PLAIN, 16));
        txtPrice = makeTextField();
        contentPanel.add(lblPrice);
        contentPanel.add(txtPrice, "growx, w 250!");
// ===== Hàng 4: Quantity / Category =====
        lblQuantity = new JLabel("Quantity:");
        lblQuantity.setFont(new Font("sansserif", Font.PLAIN, 16));
        spinnerQuantity = new JSpinner(new SpinnerNumberModel(1, 1, 1000000, 1));
        contentPanel.add(lblQuantity);
        contentPanel.add(spinnerQuantity, "growx, w 250!");
lblCate = new JLabel("Category:");
        lblCate.setFont(new Font("sansserif", Font.PLAIN, 16));
        // Menu chọn category (giữ nguyên cách bạn đang làm)
        JMenuBar menuBar = new JMenuBar();
        menu = new JMenu("Choose");
        menu.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        try {
            busProduct = new BusProduct();
            java.util.List<com.Admin.category.DTO.DTOCategory> listCategory = busProduct.getAllCategoriesWithSupplier();
            Map<String, JMenu> supplierMenuMap = new LinkedHashMap<>();
            for (com.Admin.category.DTO.DTOCategory dto : listCategory) {
                String supName = dto.getSupName() == null ? "Unknown Supplier" : dto.getSupName();
                JMenu supMenu = supplierMenuMap.computeIfAbsent(supName, k -> {
                    JMenu m = new JMenu(k);
                    m.setFont(new Font("Times New Roman", Font.PLAIN, 14));
                    menuBar.add(m);
                    return m;
                });
                String categoryID = String.valueOf(dto.getCategoryID());
                String categoryName = dto.getCategoryName();
                JMenuItem categoryItem = new JMenuItem(categoryName + " (ID: " + categoryID + ")");
                categoryItem.setFont(new Font("Times New Roman", Font.PLAIN, 14));
                categoryItem.addActionListener(e -> menu.setText(categoryID));
                supMenu.add(categoryItem);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            CustomDialog.showError("Không tải được danh mục: " + ex.getMessage());
        }
        menuBar.add(menu);
        contentPanel.add(lblCate);
        contentPanel.add(menuBar, "growx, w 250!");
// ===== Upload ảnh =====
        bntupload = new MyButton("Upload", 0);
        bntupload.setBackgroundColor(Color.WHITE);
        bntupload.setPressedColor(Color.decode("#D3D3D3"));
        bntupload.setHoverColor(Color.decode("#EEEEEE"));
        bntupload.setFont(new Font("sansserif", Font.BOLD, 16));
        bntupload.setButtonIcon("src\\main\\resources\\Icons\\Admin_icon\\upload_image.png",
                40, 40, 10, SwingConstants.RIGHT, SwingConstants.CENTER);
        // GIỮ NGUYÊN action listener upload của bạn (đã có ở dưới)
        contentPanel.add(new JLabel("")); // đệm
        contentPanel.add(bntupload, "growx, w 250!");
// ===== Save + Reset =====
        bntSave = new MyButton("Save", 20);
        bntSave.setBackgroundColor(Color.decode("#E55454"));
        bntSave.setPressedColor(Color.decode("#C04444"));
        bntSave.setHoverColor(Color.decode("#FF7F7F"));
        bntSave.setFont(new Font("Times New Roman", Font.BOLD, 16));
        bntSave.setForeground(Color.WHITE);
        // GIỮ NGUYÊN action saveProductFromGUI() của bạn
        contentPanel.add(new JLabel(""));
        contentPanel.add(bntSave, "w 120!, h 40!");
    
        bntReset = new MyButton("Reset", 0);
        bntReset.setBackgroundColor(Color.WHITE);
        bntReset.setPressedColor(Color.decode("#D3D3D3"));
        bntReset.setHoverColor(Color.decode("#EEEEEE"));
        bntReset.setFont(new Font("sansserif", Font.BOLD, 16));
        bntReset.addActionListener(e -> resetForm());
        contentPanel.add(new JLabel(""));
        contentPanel.add(bntReset, "w 120!, h 40!");
    
        bg.add(contentPanel, "grow, pushy");
    
        // Co font tiêu đề theo kích thước
        panelTitle.addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                float fontSize = Math.min(22f, Math.max(14f, panelTitle.getWidth() / 20f));
                lblTitle.setFont(lblTitle.getFont().deriveFont(fontSize));
            }
        });
    }
    

    private MyTextField makeTextField() {
        MyTextField field = new MyTextField();
        field.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
        field.setTextFont(new Font("Times New Roman", Font.PLAIN, 15));
        field.setBackgroundColor(Color.decode("#F0FFFF"));
        return field;
    }

    public void saveProductFromGUI() {
        String productId = txtProductID.getText().trim();
        String productName = txtProductName.getText().trim();
        String color = txtColor.getText().trim();
        String speed = txtSpeed.getText().trim();
        String batteryCapacity = txtBattery.getText().trim();
        String categoryId = menu.getText().trim();
        String priceStr = txtPrice.getText().trim();
        int quantity = (int) spinnerQuantity.getValue();
        // Use GUI image field first, fall back to busProduct if set
        String imagePath = (image != null && !image.isEmpty()) ? image : busProduct.getImagePath();

        if (productId.isEmpty() || productName.isEmpty() || color.isEmpty()
                || speed.isEmpty() || batteryCapacity.isEmpty()
                || categoryId.isEmpty() || priceStr.isEmpty()) {
            CustomDialog.showError("Please fill in all required fields!");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceStr);
            if (price < 0) {
                CustomDialog.showError("Price must be >= 0!");
                return;
            }
        } catch (NumberFormatException e) {
            CustomDialog.showError("Invalid price format!");
            return;
        }

        if (imagePath == null || imagePath.isEmpty()) {
            CustomDialog.showError("Please upload an image!");
            return;
        }

        DTOProduct product = new DTOProduct(
                productId, productName, color, speed, batteryCapacity,
                quantity, categoryId, imagePath, price
        );

        busProduct.saveProduct(product);
    }

    private void resetForm() {
        txtProductID.setText("");
        txtProductName.setText("");
        txtColor.setText("");
        txtBattery.setText("");
        txtSpeed.setText("");
        txtPrice.setText("");
        spinnerQuantity.setValue(1);
        image = null;
        if (menu != null) menu.setText("Choose");
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        jMenuItem1 = new javax.swing.JMenuItem();
        bg = new javax.swing.JLayeredPane();

        jMenuItem1.setText("jMenuItem1");
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setOpaque(true);

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
                bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 1414, Short.MAX_VALUE)
        );
        bgLayout.setVerticalGroup(
                bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 483, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(bg)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(bg)
        );

        pack();
        setLocationRelativeTo(null);
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {}

        java.awt.EventQueue.invokeLater(() -> new NewProduct().setVisible(true));
    }

    private javax.swing.JLayeredPane bg;
    private javax.swing.JMenuItem jMenuItem1;
}
