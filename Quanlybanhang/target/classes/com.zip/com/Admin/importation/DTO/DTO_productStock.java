package com.Admin.importation.DTO;

import java.math.BigDecimal;

public class DTO_productStock {

    private String productID;
    private String productName;
    private BigDecimal price;
    private String categoryID;
    private String supId;
    private int quantityInStock;

    public DTO_productStock() {}

    public DTO_productStock(String productID, String productName, BigDecimal price, String categoryID, String supId, int quantityInStock) {
        this.productID = productID;
        this.productName = productName;
        this.price = price;
        this.categoryID = categoryID;
        this.supId = supId;
        this.quantityInStock = quantityInStock;
    }

    public String getProductID() { return productID; }
    public void setProductID(String productID) { this.productID = productID; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }

    public String getCategoryID() { return categoryID; }
    public void setCategoryID(String categoryID) { this.categoryID = categoryID; }

    public String getSupId() { return supId; }
    public void setSupId(String supId) { this.supId = supId; }

    // Backward-compatible alias for existing GUI/DAO code
    public String getBrandID() { return supId; }
    public void setBrandID(String brandID) { this.supId = brandID; }

    public int getQuantityInStock() { return quantityInStock; }
    public void setQuantityInStock(int quantityInStock) { this.quantityInStock = quantityInStock; }
}
