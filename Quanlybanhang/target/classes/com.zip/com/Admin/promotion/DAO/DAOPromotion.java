package com.Admin.promotion.DAO;

import com.Admin.promotion.DTO.DTOPromotion;
import com.ComponentandDatabase.Database_Connection.DatabaseConnection;
import java.sql.*;
import java.time.LocalDate;

public class DAOPromotion {

    public DTOPromotion getPromotionByCode(String code) throws SQLException {
        String sql = "SELECT Promotion_Code, Promotion_Name, Start_Date, End_Date, Discount_Percent "
                   + "FROM Promotion WHERE Promotion_Code = ?";
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, code);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                DTOPromotion p = new DTOPromotion();
                p.setPromotionCode(rs.getString("Promotion_Code"));
                p.setPromotionName(rs.getString("Promotion_Name"));
                p.setStartDate(rs.getDate("Start_Date").toLocalDate());
                p.setEndDate(rs.getDate("End_Date").toLocalDate());
                p.setDiscountPercent(rs.getBigDecimal("Discount_Percent"));
                return p;
            }
            return null;
        }
    }

    public boolean isPromotionActive(String code, LocalDate onDate) throws SQLException {
        String sql = "SELECT 1 FROM Promotion WHERE Promotion_Code=? AND Start_Date<=? AND End_Date>=?";
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, code);
            ps.setDate(2, Date.valueOf(onDate));
            ps.setDate(3, Date.valueOf(onDate));
            ResultSet rs = ps.executeQuery();
            return rs.next();
        }
    }
}