package com.Admin.promotion.BUS;

import com.Admin.promotion.DAO.DAOPromotion;
import com.Admin.promotion.DTO.DTOPromotion;
import java.time.LocalDate;

public class BUSPromotion {
    private final DAOPromotion dao = new DAOPromotion();

    public DTOPromotion findActivePromotion(String code) throws Exception {
        if (code == null || code.isBlank()) return null;
        DTOPromotion p = dao.getPromotionByCode(code);
        if (p == null) return null;
        if (dao.isPromotionActive(code, LocalDate.now())) {
            return p;
        }
        return null;
    }
}